from html_message import HTMLMessage
from html_table import HTMLTable

# Version of the html_msg package 
__version__= "1.0.0"

__all__ = [
    'HTMLMessage',
    'HTMLTable'
]
